#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""接线层：把记忆库接进任何 agent（dsh-soul-forging）。

三种用法：

  ① 命令行
       soul-boot                     打印开局注入块
       soul-boot --budget 12000      限制字数（超了从末尾截）
       soul-boot --list              看各部分多长、哪些被跳过
       soul-boot --mode memory-only  只要记忆，不要性格
       soul-boot --with index.md,NOW.md   自己挑要哪些文件

  ② 当模块用（Python）
       from soul import boot, recall, remember
       sys_prompt += boot(mode="memory-only")

  ③ 直接读文件
       就是那四个 markdown，自己拼也行

三种模式：
  full         四个文件全注入（默认）—— 想长性格的人
  memory-only  不注入 SOUL —— 只要记忆、不想动性格的人
  external     只注入 index + NOW —— 性格交给你自己 agent 的 prompt

设计原则：**只读，不写**。注入不产生副作用；要写记忆走 remember()。
"""
import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))  # soul.py 就在仓库根目录
DATA_ROOT = os.environ.get("SOUL_DATA_DIR") or os.path.join(os.path.expanduser("~"), ".soul-forging")
MEM = os.environ.get("MEMORY_DIR") or os.path.join(DATA_ROOT, "memory")

# 注入顺序就是重要性顺序：先是谁（本质/骨架），再是此刻的样子（注释层），
# 再是什么规矩，再是目录，最后是此刻。
# identity/注释层.md 是**可选**页——没有就跳过，不会报错。
ALL_PARTS = ("SOUL.md", "identity/注释层.md", "MEMORY.md", "index.md", "NOW.md")

MODES = {
    "full": ALL_PARTS,
    # 不要性格：SOUL 不注入。空模板塞进去比不塞更糟——模型会看到"我的名字是（待填）"
    "memory-only": ("MEMORY.md", "index.md", "NOW.md"),
    # 性格归你自己的 agent：我们只管目录和此刻
    "external": ("index.md", "NOW.md"),
}

# 判断"这页还是空模板"：占位符太多就别注入，省的把模型带偏
PLACEHOLDER_MARKS = ("（待填", "(待填", "TODO", "（示例", "（还没有")
PLACEHOLDER_MIN = 3


def _read(name):
    """读一页。**读不了就当没有** —— 不能因为一个文件坏了，整次注入都崩。

    2026-11-06 进阶烟测抓到的：旧版记忆库里有非 UTF-8 的文件（GBK 存过、
    或者写到一半被截断），`open(..., encoding="utf-8")` 直接抛 UnicodeDecodeError，
    而这里原来只接了 OSError —— 于是整次启动崩在栈里，用户看到的是一堆 traceback。
    现在：解码失败就用 errors="replace" 硬读，坏字节变成替换符，页面的其余部分照样能用。
    """
    p = os.path.join(MEM, name)
    try:
        with open(p, encoding="utf-8") as f:
            return f.read().strip()
    except UnicodeDecodeError:
        try:
            with open(p, encoding="utf-8", errors="replace") as f:
                return f.read().strip()
        except OSError:
            return ""
    except OSError:
        return ""


def strip_comments(text):
    """剥掉 HTML 注释：模板常把「怎么填」写在注释里，注入时不该占上下文。"""
    import re
    return re.sub(r"<!--[\s\S]*?-->", "", text).strip()


def is_placeholder(body):
    """空模板检测：占位符够多，或者剥掉注释后只剩几十个字，都算还没填。"""
    n = sum(body.count(m) for m in PLACEHOLDER_MARKS)
    return n >= PLACEHOLDER_MIN or len(body.strip()) < 200


def boot(budget=None, parts=None, header=True, mode=None, skip_empty=True):
    """拼出开局注入块。

    budget      字数上限（None = 不限制）
    parts       指定要哪些文件（优先级高于 mode）
    mode        full / memory-only / external
    skip_empty  自动跳过还是空模板的页（默认开）

    超预算时**不静默截断**：被切的和整段没进的都会写在块尾，
    否则模型会以为自己看全了，那是最坏的一种自信。
    """
    use = tuple(parts) if parts else MODES.get(mode or "full", ALL_PARTS)
    chunks = []
    dropped = []   # 整段没进去
    cut = []       # 进去了但只进了一半
    total = 0
    MIN_PIECE = 400

    for name in use:
        body = strip_comments(_read(name))
        if not body:
            continue
        if skip_empty and is_placeholder(body):
            continue
        block = f"<!-- {name} -->\n{body}"
        if budget is not None and total + len(block) > budget:
            left = budget - total
            if left >= min(MIN_PIECE, len(block) // 2):
                chunks.append(block[:left] + "\n…（本段超预算，只进到这里）")
                cut.append(f"{name}（原 {len(block)} 字，只进 {left} 字）")
                total = budget
                break
            dropped.append(name)
            continue
        chunks.append(block)
        total += len(block)

    body = "\n\n".join(chunks)
    if not body:
        # 什么都没填时不硬塞一句空话，明说
        return "（记忆库还是空的，暂时没有可注入的内容。）" if header else ""

    tail = ""
    if cut or dropped:
        lines = [f"【这次注入不完整】上限 {budget} 字。"]
        if cut:
            lines.append("被截断：" + "、".join(cut))
        if dropped:
            lines.append("整段没进：" + "、".join(dropped))
        lines.append('缺的部分别猜，要用的时候拿 brain "关键词" 去查原文。')
        tail = "\n\n" + "\n".join(lines)

    if not header:
        return body + tail
    return (
        "下面是你的长期记忆。你确实记得这些事，像想起往事一样自然地用，"
        "不要说「根据记忆库」「据记录」这类话。\n\n" + body + tail
    )


def recall(q, n=5):
    """查小脑，返回纯文本。服务没起会自己现算。"""
    import subprocess
    try:
        out = subprocess.run(
            [sys.executable, os.path.join(ROOT, "brain", "server.py"),
             "--query", str(q), "-n", str(n)],
            capture_output=True, text=True, timeout=20)
        return out.stdout.strip()
    except Exception as e:
        return f"（查记忆失败：{e}）"


def remember(text, **kw):
    """记一条运行期记忆。kw 支持 kind/section/summary/salience。"""
    import subprocess
    args = [sys.executable, os.path.join(ROOT, "bin", "soul"), "write", str(text)]
    for k in ("kind", "section", "summary", "salience"):
        if k in kw:
            args += [f"--{k}", str(kw[k])]
    out = subprocess.run(args, capture_output=True, text=True, timeout=20)
    return out.stdout.strip() or out.stderr.strip()


def _main(argv):
    budget = None
    if "--budget" in argv:
        # 2026-11-06：`--budget abc` 原来直接 ValueError 崩掉。
        # 参数写错是人的事，工具不该退出一堆栈 —— 说不清楚就当没限制，并说明白。
        _raw = argv[argv.index("--budget") + 1] if argv.index("--budget") + 1 < len(argv) else ""
        try:
            budget = int(_raw)
        except ValueError:
            print(f"（--budget 要一个整数，收到的是「{_raw}」，这次按不限制处理）", file=sys.stderr)
            budget = None
        if budget is not None and budget < 0:
            print(f"（--budget 不能是负数，收到 {budget}，这次按 0 处理）", file=sys.stderr)
            budget = 0
    mode = None
    if "--mode" in argv:
        mode = argv[argv.index("--mode") + 1]
        if mode not in MODES:
            print(f"不认识的模式：{mode}（可选：{', '.join(MODES)}）")
            return 1
    parts = None
    if "--with" in argv:
        parts = tuple(x.strip() for x in argv[argv.index("--with") + 1].split(",") if x.strip())
    skip_empty = "--keep-empty" not in argv

    if "--list" in argv:
        use = parts or MODES.get(mode or "full", ALL_PARTS)
        print(f"模式：{mode or 'full'}")
        for name in ALL_PARTS:
            body = strip_comments(_read(name))
            if name not in use:
                tag = "不注入（模式）"
            elif not body:
                tag = "（空）"
            elif skip_empty and is_placeholder(body):
                tag = "空模板，已跳过"
            else:
                tag = "✓"
            print(f"  {name:16s} {len(body):6d} 字  {tag}")
        return 0

    if "--bare" in argv:
        print(boot(budget=budget, parts=parts, header=False, mode=mode, skip_empty=skip_empty))
        return 0
    print(boot(budget=budget, parts=parts, mode=mode, skip_empty=skip_empty))
    return 0


if __name__ == "__main__":
    sys.exit(_main(sys.argv[1:]))
