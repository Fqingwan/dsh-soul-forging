#!/usr/bin/env bash
# 装机烟测 —— 每次 npm publish 之前必须跑过。
#
# 为什么要有这个：源码目录里跑一百遍都是好的，装出来才炸。
# 已经栽过三次：
#   ① .bin 里是软链接，按 $0 推上级目录指错
#   ② 数据目录写进 /usr/local/lib/node_modules，权限拒绝
#   ③ runlog 没执行位；后来又用 python 去跑 bash 脚本
#
# 这个脚本模拟「全新机器 + 全局安装 + 干净 HOME」：
#   npm pack → 装进临时 prefix → 用干净 HOME 跑每一条命令 → 逐项断言
#
# 用法: bash scripts/smoke.sh
set -uo pipefail
cd "$(dirname "$0")/.."
ROOT="$(pwd)"

PASS=0; FAIL=0
ok()   { PASS=$((PASS+1)); printf '  ✓ %s\n' "$1"; }
bad()  { FAIL=$((FAIL+1)); printf '  ✗ %s\n     %s\n' "$1" "${2:-}"; }

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
export HOME="$TMP/home"; mkdir -p "$HOME"
PREFIX="$TMP/prefix"; mkdir -p "$PREFIX"

echo "== 1. 打包 =="
TGZ=$(npm pack --silent 2>/dev/null | tail -1)
[ -f "$TGZ" ] && ok "npm pack → $TGZ" || { bad "npm pack"; exit 1; }

echo "== 2. 全局安装（模拟 /usr/local）=="
INSTALL_LOG=$TMP/install.log
if ! npm i -g --prefix "$PREFIX" "$ROOT/$TGZ" >"$INSTALL_LOG" 2>&1; then
  bad "安装失败" "$(grep -E 'npm (ERR|error)' "$INSTALL_LOG" | head -2 | tr '\n' ' ')"
  exit 1
fi
BIN="$PREFIX/bin"
[ -x "$BIN/soul" ] && ok "命令已安装到 $BIN" || { bad "安装后没有 soul 命令" "$(ls "$PREFIX" 2>/dev/null | tr '\n' ' ')"; exit 1; }
VER=$(node -e "console.log(require('$PREFIX/lib/node_modules/dsh-soul-forging/package.json').version)")
ok "版本 $VER"

check_pkg_clean() {
  node -e "
const fs=require('fs');const p='$PREFIX/lib/node_modules/dsh-soul-forging';
const bad=['brain/entries.json','brain/state.json','brain/live.jsonl','brain/snapshots']
  .filter(f=>fs.existsSync(p+'/'+f));
if(bad.length){console.log(bad.join(','));process.exit(1)}
" 2>/dev/null
}

echo "== 3. 逐条命令 =="
run() { # 名字 命令...
  local name="$1"; shift
  local out; out=$("$@" 2>&1); local rc=$?
  if [ $rc -eq 0 ] && [ -n "$out" ]; then ok "$name"; else bad "$name" "rc=$rc ${out:0:120}"; fi
  LAST_OUT="$out"
}

run "soul-init"      "$BIN/soul-init"
run "soul-boot"      "$BIN/soul-boot" --list
# sync 永远 exit 0（失败也返回 0，只是打印"有失败项"），所以必须看输出
sync_ok() {
  local out; out=$("$BIN/soul-sync" 2>&1)
  echo "$out" | grep -q "^sync ok$" && ok "soul-sync（干净）" && return 0
  bad "soul-sync 有失败项" "$(echo "$out" | grep -E '失败' | head -1)"
  return 1
}
sync_ok
run "soul (write)"   "$BIN/soul" write "烟测写的一条"
sync_ok
run "soul-recall"    "$BIN/soul-recall" "烟测" 1
echo "$LAST_OUT" | grep -q "烟测写的一条" && ok "检索命中刚写的内容" || bad "检索没命中"

# 服务类：起在随机高位端口，测完杀掉
PORT=$(( (RANDOM % 2000) + 39000 ))
BRAIN_PORT=$PORT "$BIN/soul-serve" >/dev/null 2>&1
sleep 1
curl -s -m 3 "http://127.0.0.1:$PORT/health" | grep -q '"ok": true' && ok "soul-serve 起得来" || bad "soul-serve"
BRAIN_PORT=$PORT "$BIN/soul-sync" 2>&1 | grep -q "^sync ok$" && ok "sync（服务在跑时）" || bad "sync（服务在跑时）"

run "soul-check"     "$BIN/soul" check
run "soul-forget"    "$BIN/soul-forget"
run "soul-snapshot"  "$BIN/soul-snapshot" save "烟测"
run "soul-peer"      "$BIN/soul-peer" export
run "soul-sediment"  "$BIN/soul-sediment"
run "soul-review"    "$BIN/soul-review"
run "soul-archive"   "$BIN/soul-archive"
run "soul-debug"     "$BIN/soul-debug"

echo "== 4. 包目录必须干净（跑完所有命令之后查）=="
DIRTY=$(check_pkg_clean) && ok "包目录没被写脏" || bad "包目录被污染：$DIRTY"

echo "== 5. 三种模式（不想改性格的人）=="
# memory-only：不该生成 SOUL，注入里不该出现性格
export MEMORY_DIR="$TMP/mem2"
"$BIN/soul-init" --memory-only >/dev/null 2>&1
[ ! -f "$MEMORY_DIR/SOUL.md" ] && ok "memory-only 不生成 SOUL.md" || bad "memory-only 还是生成了 SOUL"
grep -q "^status: skip" "$MEMORY_DIR/BOOTSTRAP.md" 2>/dev/null && ok "memory-only 把铸魂标成 skip" || bad "memory-only 铸魂还停在 pending（会反复催）"
"$BIN/soul-boot" --mode memory-only --list 2>&1 | grep -q "不注入（模式）" && ok "memory-only 不注入 SOUL" || bad "memory-only 仍在注入 SOUL"
# external：连 BOOTSTRAP 都不铺
MEMORY_DIR="$TMP/mem3" "$BIN/soul-init" --external >/dev/null 2>&1
[ ! -f "$TMP/mem3/BOOTSTRAP.md" ] && ok "external 不铺铸魂清单" || bad "external 还铺了 BOOTSTRAP"
MEMORY_DIR="$TMP/mem3" "$BIN/soul-boot" --mode external 2>&1 | grep -q "记忆库还是空的" && ok "external 空库时不硬塞东西" || bad "external 空库仍注入了内容"
# 空模板保护：没填的 SOUL 不许进上下文
MEMORY_DIR="$TMP/mem2" "$BIN/soul-boot" --keep-empty 2>&1 | grep -q "（待填" && ok "占位符确实存在（对照）" || true
MEMORY_DIR="$TMP/mem2" "$BIN/soul-boot" 2>&1 | grep -q "（待填" && bad "空模板被注入了" || ok "空 SOUL 不会进上下文"
unset MEMORY_DIR

echo "== 6. 注释层与注入预算 =="
export MEMORY_DIR="$TMP/mem4"
"$BIN/soul-init" >/dev/null 2>&1
[ -f "$MEMORY_DIR/identity/注释层.md" ] && ok "init 铺了 identity/注释层.md" || bad "init 没铺注释层"
"$BIN/soul-boot" 2>&1 | grep -q "（待填" && bad "空注释层被注入" || ok "空注释层不进上下文"

# 填一份能用的，查注入顺序：SOUL → 注释层 → MEMORY
python3 - "$MEMORY_DIR" <<'PYX'
import sys, os
m = sys.argv[1]
def w(rel, head, n):
    # 2026-11-05：原来这里写的是 head + "。\n"*n —— 只重复了句号，
    # 正文根本不到 200 字，被「剥注释后 <200 字算空」判空跳过，
    # 于是后面三个断言连环失败。测试数据要把**整句**重复够。
    os.makedirs(os.path.dirname(os.path.join(m, rel)) or m, exist_ok=True)
    body = head + "\n" + ("这一句用来把长度撑够，重复一遍又一遍。\n" * n)
    open(os.path.join(m, rel), "w", encoding="utf-8").write(body)
w("SOUL.md", "# SOUL\n我是烟测人格，骨架第一句", 40)
w("identity/注释层.md", "# 注释层\n我此刻的样子，连着写不列条目", 40)
w("MEMORY.md", "# MEMORY\n规则若干", 40)
w("index.md", "# Index\n目录若干", 10)
w("NOW.md", "# NOW\n此刻", 10)
PYX
BOUT=$("$BIN/soul-boot" 2>&1)
echo "$BOUT" | grep -q "注释层" && ok "注释层参与注入" || bad "注释层没进注入"
SL=$(echo "$BOUT" | grep -n "^<!-- SOUL.md -->" | head -1 | cut -d: -f1)
CL=$(echo "$BOUT" | grep -n "^<!-- identity/注释层.md -->" | head -1 | cut -d: -f1)
ML=$(echo "$BOUT" | grep -n "^<!-- MEMORY.md -->" | head -1 | cut -d: -f1)
if [ -n "$SL" ] && [ -n "$CL" ] && [ -n "$ML" ] && [ "$SL" -lt "$CL" ] && [ "$CL" -lt "$ML" ]; then
  ok "注入顺序：SOUL → 注释层 → MEMORY"
else
  bad "注入顺序不对" "SOUL=$SL 注释层=$CL MEMORY=$ML"
fi
# 2026-11-05：原来 SOUL 就超过预算，600 字全被它吃掉（只截不留），
# 永远走不到「整段没进」那条分支。现在把 SOUL 写小、MEMORY 写大，
# 让 MEMORY 整段进不去 —— 这才测得到那个分支。
python3 - "$MEMORY_DIR" <<'PYX2'
import sys, os
m = sys.argv[1]
# SOUL 要 ~235 字：太短则剩余预算够截 MEMORY（只截不留），太长则把预算全吃光。
# 只有留下不到 400 字的余量，MEMORY 才会被判「整段没进」。
open(os.path.join(m, "SOUL.md"), "w", encoding="utf-8").write(
    "# SOUL\n我是烟测人格，短一点。\n" + ("这一句用来把长度撑够。\n" * 18))
open(os.path.join(m, "MEMORY.md"), "w", encoding="utf-8").write(
    "# MEMORY\n规则若干\n" + ("这一句用来把长度撑够，重复一遍又一遍。\n" * 60))
PYX2
TBOUT=$("$BIN/soul-boot" --budget 600 2>&1)
echo "$TBOUT" | grep -q "这次注入不完整" && ok "超预算时会明说被截" || bad "超预算静默截断"
echo "$TBOUT" | grep -q "整段没进" && ok "截断清单列了整段没进的" || bad "没列整段没进的"
# 预算充足时不该有多余提示
"$BIN/soul-boot" --budget 60000 2>&1 | grep -q "这次注入不完整" && bad "预算够还报截断" || ok "预算够时不报截断"

echo "== 7. 真遗忘（soul-purge）=="
# 2026-11-05：这一段原来接着用第 6 段的 MEMORY_DIR，可 BRAIN_DIR 落在别处，
# 一个写、一个读，两边根本不是一个库 —— 预演自然找不到。现在自己立一套。
export SOUL_DATA_DIR="$TMP/home/.soul-forging"
export MEMORY_DIR="$SOUL_DATA_DIR/memory"
export BRAIN_DIR="$SOUL_DATA_DIR/brain"
"$BIN/soul-init" >/dev/null 2>&1
"$BIN/soul" write "烟测要用遗忘洗掉的这句话" >/dev/null 2>&1
"$BIN/soul-purge" "烟测要用遗忘洗掉" 2>&1 | grep -q "行" && ok "purge 预演能定位" || bad "purge 预演没找到"
"$BIN/soul-purge" "烟测要用遗忘洗掉" --apply 2>&1 | grep -q "已删" && ok "purge --apply 执行成功" || bad "purge --apply 失败"
"$BIN/soul-recall" "烟测要用遗忘洗掉" 1 2>&1 | grep -q "洗掉" && bad "purge 之后还搜得到" || ok "purge 之后搜不到"
[ -f "$BRAIN_DIR/forgotten.json" ] && ok "留了指纹文件" || bad "没留 forgotten.json"
grep -q "烟测要用遗忘洗掉" "$BRAIN_DIR/forgotten.json" 2>/dev/null && bad "指纹文件里存了原词" || ok "指纹只存哈希不存原词"

echo "== 8. 插件加载 =="
export MEMORY_DIR="$TMP/home/.soul-forging/memory"
node -e "
import('$PREFIX/lib/node_modules/dsh-soul-forging/lib/plugin.js').then(m=>{
  const memoryDir = process.env.MEMORY_DIR;
  let c;
  const ctx = {systemPrompt:{context(o){c=o;return()=>{}}}, skills:{register(){return()=>{}}}, logger:{info(){},warn(){}}};
  m.apply(ctx, memoryDir ? {memoryDir} : {});
  const t = c.text({});
  if(typeof m.name!=='string') throw new Error('name 缺失');
  if(!Array.isArray(m.inject)) throw new Error('inject 缺失');
  if(!t || t.length<100) throw new Error('注入块太短: '+t.length);
  const mm = m.bootBlock(memoryDir, 20000, { mode: 'memory-only' });
  const ee = m.bootBlock(memoryDir, 20000, { mode: 'external' });
  if(typeof mm!=='string' || typeof ee!=='string') throw new Error('模式参数不可用');
  if(ee.includes('小蓝') && !t.includes('小蓝')) throw new Error('模式串了');
  console.log('OK '+t.length);
}).catch(e=>{console.log('FAIL '+e.message);process.exit(1)})
" >/tmp/smoke-plugin.out 2>&1
grep -q "^OK" /tmp/smoke-plugin.out && ok "插件注入 $(cut -d' ' -f2 /tmp/smoke-plugin.out) 字" \
  || bad "插件加载" "$(cat /tmp/smoke-plugin.out | head -2)"

rm -f "$ROOT/$TGZ"
echo
echo "===== 通过 $PASS · 失败 $FAIL ====="
[ $FAIL -eq 0 ] || exit 1
echo "✓ 可以发"
